
const products = [
    {
        name: "Logitech G502 Lightspeed Wireless Gaming Mouse",
        img: "https://m.media-amazon.com/images/I/61LtuGzXeaL._SX679_.jpg",
        price: 6855,
        description: "High-performance wireless gaming mouse with HERO 25K sensor."
    },
    {
        name: "Redragon Kumara K552 Mechanical Gaming Keyboard",
        img: "https://m.media-amazon.com/images/I/71eUwDk8z+L._SX522_.jpg",
        price: 2299,
        description: "Compact mechanical keyboard with red LED backlighting."
    }
];

const productContainer = document.querySelector('.products');
products.forEach(product => {
    const card = document.createElement('div');
    card.className = 'product';
    card.innerHTML = `
        <img src="${product.img}" alt="${product.name}" />
        <h3>${product.name}</h3>
        <p>₹${product.price}</p>
        <p>${product.description}</p>
        <button>Buy Now</button>
    `;
    productContainer.appendChild(card);
});
